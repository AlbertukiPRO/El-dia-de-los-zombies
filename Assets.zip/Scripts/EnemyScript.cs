using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour
{

    public GameObject Player;

    public int rutina;
    public float cronometro;
    public Animator Animator;
    public int direc;
    public float walk_speed;

    public bool atacando;
    public float rango_vision;
    public float rango_ataque;
    public GameObject hit;

    private void Start()
    {

        Animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
      
        Comportamientos();
    }

    public void Comportamientos()
    {
        if (Mathf.Abs(transform.position.x - Player.transform.position.x) > rango_vision && !atacando)
        {
            Animator.SetBool("attack", false);
            cronometro += 1 * Time.deltaTime;

            if (cronometro >= 3)
            {
                rutina = Random.Range(0, 2);
                cronometro = 0;
            }

            switch (rutina)
            {
                case 0:
                    Animator.SetBool("walk", false);
                    break;

                case 1:
                    direc = cronometro >= 3 ? 0 : 1; 
                    rutina++;
                    break;
                case 2:
                    switch (direc)
                    {
                        case 0:
                            transform.rotation = Quaternion.Euler(0, 0, 0);
                            transform.Translate(Vector3.right * walk_speed * Time.deltaTime);
                            break;
                        case 1:
                            transform.rotation = Quaternion.Euler(0, 180, 0);
                            transform.Translate(Vector3.right * walk_speed * Time.deltaTime);
                            break;
                    }
                    Animator.SetBool("walk", true);
                    break;
            }
        }
        else
        {
            if(Mathf.Abs(transform.position.x - Player.transform.position.x) > rango_ataque && !atacando)
            {
                if (transform.position.x < Player.transform.position.x)
                { 
                    Animator.SetBool("walk", false);
                    Animator.SetBool("walk", true);
                    transform.Translate(Vector3.right * walk_speed * Time.deltaTime);
                    transform.rotation = Quaternion.Euler(0, 0, 0);
                    Animator.SetBool("attack", false);
                }
                else
                {
                    Animator.SetBool("walk", false);
                    Animator.SetBool("walk", true);
                    transform.Translate(Vector3.right * walk_speed * Time.deltaTime);
                    transform.rotation = Quaternion.Euler(0, 180, 0);
                    Animator.SetBool("attack", false);
                }
            }
            else
            {
                if (!atacando)
                {
                    if(transform.position.x < Player.transform.position.x)
                    {
                        transform.rotation = Quaternion.Euler(0, 0, 0);
                    }
                    else
                    {
                        transform.rotation = Quaternion.Euler(0, 180, 0);
                    }
                    Animator.SetBool("walk", false);
                }
            }
        }
    }

    public void Final_Ani()
    {
        Animator.SetBool("attack", false);
        atacando = false;

        Player.GetComponent<BoxCollider2D>().enabled = true;
    }

    public void ColliderWeaponTrue()
    {
        hit.GetComponent<BoxCollider2D>().enabled = true;
    }

    public void ColliderWeaponFalse()
    {
        hit.GetComponent<BoxCollider2D>().enabled = false;
    }
}
