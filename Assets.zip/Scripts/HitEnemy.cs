using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HitEnemy : MonoBehaviour
{
    public Animator Animator;
    // Start is called before the first frame update
    public Image barraVida;
    public float vidaActual;
    public float vidaMaxima;
    public float hit_rate;

    public bool dead;

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            print("Da�o");
            vidaActual -= hit_rate;
            barraVida.fillAmount = vidaActual / vidaMaxima;

            if (vidaActual == 0)
            {
                Animator.SetBool("walk", false);
                Animator.SetBool("attack", false);
                Animator.SetBool("dead", true);

                dead = true;
            }
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
